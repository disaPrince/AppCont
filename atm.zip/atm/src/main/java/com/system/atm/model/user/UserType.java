package com.system.atm.model.user;

public enum  UserType {
    Children, Retiree, Single;
}
